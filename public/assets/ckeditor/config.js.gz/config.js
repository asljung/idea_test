CKEDITOR.config.toolbar_mini =
    [
        ['Format'],
        ['Bold','Italic','Underline','Strike','-','Subscript','Superscript'],
        ['Undo','Redo','-','Find','Replace','-','SelectAll','RemoveFormat'],
        ['NumberedList','BulletedList','-','Outdent','Indent'],
        ['JustifyLeft','JustifyCenter','JustifyRight','JustifyBlock'],
        ['Link','Unlink'],
        ['Image','Table','HorizontalRule']  
    ];
